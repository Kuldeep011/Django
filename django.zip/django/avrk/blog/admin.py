from django.contrib import admin
from blog.models import Blog
class BlogAdmin(admin.ModelAdmin):
    list_display=('blog_Image','blog_Title','blog_Article')

admin.site.register(Blog,BlogAdmin)
# Register your models here.
