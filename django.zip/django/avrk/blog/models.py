from django.db import models
from tinymce.models import HTMLField
from autoslug import AutoSlugField
# Create your models here.
class Blog(models.Model):
    blog_Title=models.CharField(max_length=50)
    blog_Image=models.FileField(upload_to="blog/", max_length=250,null=True, default=None)
    blog_Article=HTMLField()
    slug=AutoSlugField(populate_from='blog_Title',unique=True,null=True,default=None)

