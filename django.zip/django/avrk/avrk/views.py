from django.http import HttpResponse
from django.shortcuts import render
from blog.models import Blog
from contact.models import Contact
from django.core.mail import send_mail

def home(request):
    return render(request,'index.html')

def contact(request):
    return render(request,"contact.html")

def fees_structure(request):
    return render(request,"fees.html")

def admin(request):
    return render(request,'admin.html')

def blog(request):
    blog_data=Blog.objects.all()
    data={
        'blog_data':blog_data
    }
    return render(request,"blog.html",data)

def about(request):
    return render(request,"about.html")

def article(request,slug):
    dis=Blog.objects.get(slug=slug)
    data={
        'dis':dis
    }
    return render(request,"article.html",data)

def saveContact(request):
    n="" 
    f=False
    if request.method=="POST":
        name=request.POST.get('fname')
        email=request.POST.get('email')
        query=request.POST.get('query')
        d=Contact(Name=name,Email=email,Query=query)
        d.save()
        n="Thank you for contacting us, we will get back to you as soon as possible."
        f=True

        send_mail(
        "AVRK Institute Of Computer Science",
        f"Dear {name},\n\nThank you for contacting us, we will get back to you as soon as possible.\n\nThanks and regards.",
        "kv990101@gmail.com",
        [email],
        fail_silently=False,
        )

        send_mail(
        f"Query raised by {name} - AVRK",
        f"Dear Admin,\n\nQuery by {name} mentioned below\n\n{query}\n\nThanks and regards.",
        "kv990101@gmail.com",
        ["kv990101@gmail.com"],
        fail_silently=False,
        )
    return render(request,"contact.html",{'n':n,'f':f})