from django.shortcuts import render,redirect
from django.http import HttpResponse
from Letter.models import LetterData,Compose
from time import gmtime, strftime
from django.http import FileResponse
import io
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import letter
from reportlab.lib.utils import ImageReader

def letter_pdf(request):
    lines = []
    title=""
    serial=""
    date=""
    if request.method == "POST":
        lines = request.POST.getlist('body')
        title=request.POST.get('recipient')
        serial=request.POST.get('sn')
        date=request.POST.get('date')
    # Create Bytestream buffer
    buf = io.BytesIO()

    # Load logo image
    logo_path = 'static/logo3.jpg'
    logo = ImageReader(logo_path)

    # Set margin and logo position
    margin = 0.2 * inch  # Adjust the margin as needed
    logo_x = margin  # Margin from the left edge
    margin = 0.5 * inch
    logo_y = letter[1] - margin  # Margin from the top edge

    # Create a canvas
    c = canvas.Canvas(buf, pagesize=letter, bottomup=1)

    # Draw the logo
    c.drawImage(logo, logo_x, logo_y - 100, width=600, height=130)  # Adjust width and height as needed

    # Set text position
    text_x = logo_x + 65  # Adjust based on the logo width and your preference
    text_y = logo_y - 120   # Adjust based on the logo height and your preference

    # Create a text object
    textob = c.beginText()
    textob.setTextOrigin(text_x, text_y)
    textob.setFont("Helvetica", 11)
    # Add lines of text
    textob.textLine("Ref No: "+serial+"                                                                Date: "+date)
    textob.setFont("Helvetica", 15)
    text_x = logo_x + 210  
    text_y = logo_y - 170 
    textob.setTextOrigin(text_x, text_y)
    textob.textLine(title)
    text_x = logo_x + 65  
    text_y = logo_y - 200
    textob.setTextOrigin(text_x, text_y)
    textob.setFont("Helvetica", 11)
    for line in lines:
        textob.textLine(line)

    # Draw text
    c.drawText(textob)

    # Finish Up
    c.showPage()
    c.save()
    buf.seek(0)

    # Return the PDF file as response
    return FileResponse(buf, as_attachment=True, filename='letter.pdf')


def home(request):
    return render(request,"login.html")

def login(request):
    f=False
    if request.method=="POST":
        user=request.POST.get('username')
        password=request.POST.get('password')
        if user=="admin" and password=="admin":
            return render(request,"admindashboard.html",{'name':"Admin"})
        elif user=="kuldeep" and password=="love2001":
            return render(request,"dashboard.html",{'name':"Kuldeep"})
        else:
            f=True
            return render(request,"login.html",{'msg':"Invalid Username or Password", 'f':f})

def compose(request):
    code=LetterData.objects.all().values_list('unicode',flat=True).order_by('-sr')[:1]
    sn={
    'code':code.first()
    }
    return render(request,"compose.html",sn)


def unicode(request):
    num=LetterData.objects.all().values_list('sr',flat=True).order_by('-sr')[:1]
    n={
        'num':num.first()
    }
    nn=int(n["num"])+1
    if request.method=="POST":
        sn=request.POST.get('code')
        d=LetterData(sr=nn,unicode=sn)
        d.save()
    return render(request,"unicode.html",{'num':nn})

def status(request):
    data=Compose.objects.all().order_by('-sr')
    sn={
        'code':data
    }
    return render(request,"status.html",sn)

def history(request):
    data=Compose.objects.all().order_by('-sr')
    sn={
        'code':data
    }
    return render(request,"history.html",sn)

def department(request):
    code=Compose.objects.all().order_by('-sr')
    if request.method=="POST":
        st=request.POST.get('department')
        if st!=None:
            code=Compose.objects.filter(sr__icontains=st)
    sn={
        'code':code
    }
    return render(request,"dept.html",sn)

def sendCompose(request):
    if request.method=="POST":
        sr=request.POST.get('sn')
        title=request.POST.get('recipient')
        date=request.POST.get('date')
        dept=request.POST.get('department')
        side=request.POST.get('side')
        body=request.POST.get('body')
        
        sendingDate = strftime("%d-%m-%Y", gmtime())
        d=Compose(sr=sr,title=title,date=date,dept=dept,side=side,body=body,Sending_Date=sendingDate)
        d.save()
    return render(request,"compose.html")

