from django.contrib import admin
from Letter.models import LetterData, Compose

class LetterAdmin(admin.ModelAdmin):
    list_display=('sr','unicode',)

class ComposeeAdmin(admin.ModelAdmin):
    list_display=('sr','title','date','dept','side','body','Sending_Date','status')

admin.site.register(LetterData,LetterAdmin)
admin.site.register(Compose,ComposeeAdmin)
admin.site.site_header="AKS University - Letter Sender"
admin.site.site_title="AKS University - Letter Sender"

