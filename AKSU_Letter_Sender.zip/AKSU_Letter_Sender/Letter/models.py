from django.db import models

# Create your models here.
class LetterData(models.Model):
    unicode=models.CharField(max_length=250,primary_key=True)
    sr=models.CharField(max_length=250)
    
class Compose(models.Model):
    sr=models.CharField(max_length=250)
    title=models.CharField(max_length=250)
    date=models.DateField()
    dept=models.CharField(max_length=50)
    side=models.CharField(max_length=50)
    body=models.TextField()
    Sending_Date=models.CharField(max_length=50)
    status=models.CharField(max_length=50, default="Pending")